package com.example.weatherapp.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("weather_prefs")

class StorageManager(private val context: Context) {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val listType = Types.newParameterizedType(List::class.java, Location::class.java)
    private val jsonAdapter = moshi.adapter<List<Location>>(listType)
    private val locationAdapter = moshi.adapter(Location::class.java)

    private val KEY_FAVORITES = stringPreferencesKey("favorites")
    private val KEY_CURRENT_CITY = stringPreferencesKey("current_city")

    // 读取当前城市
    val currentCityFlow: Flow<Location?> = context.dataStore.data.map { prefs ->
        prefs[KEY_CURRENT_CITY]?.let { json ->
            try { locationAdapter.fromJson(json) } catch (e: Exception) { null }
        }
    }

    // 读取收藏列表
    val favoritesFlow: Flow<List<Location>> = context.dataStore.data.map { prefs ->
        prefs[KEY_FAVORITES]?.let { json ->
            try { jsonAdapter.fromJson(json) ?: emptyList() } catch (e: Exception) { emptyList() }
        } ?: emptyList()
    }

    suspend fun saveCurrentCity(city: Location) {
        val json = locationAdapter.toJson(city)
        context.dataStore.edit { it[KEY_CURRENT_CITY] = json }
    }

    suspend fun saveFavorites(list: List<Location>) {
        val json = jsonAdapter.toJson(list)
        context.dataStore.edit { it[KEY_FAVORITES] = json }
    }
}